import { isObject } from "../utils";

class Observer {
  constructor(data) {
    // 对对象中的所有属性进行劫持
    this.walk(data);
  }

  walk(data) {
    Object.keys(data).forEach((key) => {
      defineReactive(data, key, data[key]);
    });
  }
}

// 将data中每个属性 用 defineProperty重新的定义
// 因为是遍历+递归，所以性能差
function defineReactive(data, key, value) {
  // 如果属性的值也是一个对象，就再进行劫持
  observe(value);
  Object.defineProperty(data, key, {
    get() {
      return value;
    },
    set(newVal) {
      // 如果用户新赋值一个对象，也要对其进行劫持
      observe(newVal);
      value = newVal;
    },
  });
}

export function observe(data) {
  // 如果是对象才观测
  if (!isObject(data)) {
    return;
  }

  // 默认最外层的data是一个对象
  return new Observer(data);
}
