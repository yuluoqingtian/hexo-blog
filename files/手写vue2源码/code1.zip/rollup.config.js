import babel from 'rollup-plugin-babel'
// rollup 打包配置文件
export default {
  input: "./src/index.js", // 入口
  output: {
    file: "./dist/vue.js", //出口
    name: "Vue", // 指定输出的包的名称（变量名）用于在浏览器环境中通过<script>标签引入打包后的文件时，暴露的全局变量名
    format:'umd', //导出的代码使用何种模块化规范，可选值：amd、cjs、es、iife、umd、system
    sourcemap:true, // 希望可以调试源代码
  },
  plugins:[
    babel({
        exclude:'node_modules/**' // 排除node_module的所有文件
    })
  ]
};
